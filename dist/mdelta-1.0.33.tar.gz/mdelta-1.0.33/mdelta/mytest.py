def myself():
    print("Hello, nice to meet you, I am Ee While")
