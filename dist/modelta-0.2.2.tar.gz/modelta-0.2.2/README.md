# modelta

Chen and Yang Lab Multi fork Development cell lineage tree alignment.

<!-- TOC -->

- [modelta](#modelta)
  - [01 Brief introduction](#01-brief-introduction)

<!-- /TOC -->

## 01 Brief introduction

`pip install modelta`