def demola():
    print("something output!")